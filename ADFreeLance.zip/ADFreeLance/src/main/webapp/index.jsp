
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FreelanceHub | Connect & Work</title>
    <style>
        /* Modern Reset & Variables */
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --dark: #1e293b;
            --light: #f8fafc;
            --text-main: #334155;
            --text-muted: #64748b;
            --white: #ffffff;
            --shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        }

        body {
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            background-color: var(--light);
            color: var(--text-main);
            line-height: 1.6;
        }

        /* Navbar Enhancement */
        .navbar {
            background-color: var(--white);
            padding: 1rem 10%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .navbar h2 {
            margin: 0;
            color: var(--primary);
            font-size: 1.5rem;
            font-weight: 800;
            letter-spacing: -0.5px;
        }

        .nav-links a {
            color: var(--dark);
            text-decoration: none;
            margin-left: 25px;
            font-size: 0.95rem;
            font-weight: 500;
            transition: color 0.2s;
        }

        .nav-links a:hover {
            color: var(--primary);
        }

        /* Hero Section */
        .hero {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            min-height: 70vh;
            padding: 0 20px;
        }

        .hero-card {
            background: var(--white);
            padding: 3rem;
            border-radius: 16px;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
        }

        .hero h1 {
            font-size: 2.5rem;
            color: var(--dark);
            margin-bottom: 1rem;
            letter-spacing: -1px;
        }

        .hero p {
            font-size: 1.15rem;
            color: var(--text-muted);
            margin-bottom: 2rem;
        }

        /* Buttons Enhancement */
        .btn {
            display: inline-block;
            padding: 12px 28px;
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn-primary {
            background-color: var(--primary);
            color: var(--white);
            border: none;
            box-shadow: 0 4px 14px 0 rgba(79, 70, 229, 0.39);
        }

        .btn-primary:hover {
            background-color: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(79, 70, 229, 0.23);
        }

        .btn-outline {
            background-color: transparent;
            color: var(--primary);
            border: 2px solid var(--primary);
            margin-left: 10px;
        }

        .btn-outline:hover {
            background-color: #eef2ff;
            transform: translateY(-2px);
        }

        /* Footer */
        .footer {
            margin-top: 50px;
            text-align: center;
            padding: 2rem;
            background-color: var(--dark);
            color: var(--white);
        }

        .footer p {
            margin: 0;
            opacity: 0.8;
            font-size: 0.9rem;
        }

        /* Responsive */
        @media (max-width: 600px) {
            .hero h1 { font-size: 2rem; }
            .btn { width: 100%; margin: 10px 0; box-sizing: border-box; }
            .btn-outline { margin-left: 0; }
        }
    </style>
</head>

<body>

    <nav class="navbar">
        <h2>FreelanceHub</h2>
        <div class="nav-links">
            <a href="jsp/login.jsp">Login</a>
            <a href="jsp/register.jsp">Register</a>
        </div>
    </nav>

    <main class="hero">
        <div class="hero-card">
            <h1>Welcome to FreelanceHub</h1>
            <p>The world's destination for design, development, and digital talent. Find work or hire skilled freelancers easily.</p>

            <div class="action-area">
                <a href="jsp/register.jsp" class="btn btn-primary">Get Started</a>
                <a href="jsp/login.jsp" class="btn btn-outline">Sign In</a>
            </div>
        </div>
    </main>

    <footer class="footer">
        <p>© 2026 FreelanceHub. Crafted for the future of work.</p>
    </footer>

</body>
</html>