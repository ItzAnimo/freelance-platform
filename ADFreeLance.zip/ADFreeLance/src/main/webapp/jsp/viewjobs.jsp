<%@ page import="java.util.*, model.Job, model.User" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    response.setHeader("Pragma", "no-cache");
    response.setDateHeader("Expires", 0);

    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
        return;
    }

    List<Job> jobs = (List<Job>) request.getAttribute("jobs");
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Jobs | FreelanceHub</title>
    <style>
        /* Modern Variables (Synced with Platform Theme) */
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --dark: #1e293b;
            --light: #f8fafc;
            --text-main: #334155;
            --text-muted: #64748b;
            --white: #ffffff;
            --border: #e2e8f0;
            --shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
        }

        body {
            font-family: 'Segoe UI', Roboto, sans-serif;
            background-color: var(--light);
            color: var(--text-main);
            margin: 0;
            padding-bottom: 60px;
        }

        /* Navbar Enhancement */
        .navbar {
            background-color: var(--white);
            padding: 1rem 10%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow);
            border-bottom: 1px solid var(--border);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .navbar h2 {
            margin: 0;
            color: var(--primary);
            font-size: 1.4rem;
            font-weight: 800;
        }

        .nav-links a {
            color: var(--text-muted);
            text-decoration: none;
            margin-left: 20px;
            font-size: 0.9rem;
            font-weight: 500;
            transition: color 0.2s;
        }

        .nav-links a:hover {
            color: var(--primary);
        }

        /* Container & Header */
        .container {
            max-width: 900px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .header-area {
            margin-bottom: 30px;
        }

        .header-area h2 {
            color: var(--dark);
            font-size: 1.8rem;
            margin: 0;
            letter-spacing: -0.5px;
        }

        /* Job Card Styling */
        .job-card {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 25px;
            margin-bottom: 24px;
            box-shadow: var(--shadow);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .job-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        }

        .job-card h3 {
            margin: 0 0 10px 0;
            color: var(--dark);
            font-size: 1.4rem;
        }

        .job-description {
            color: var(--text-main);
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .budget-tag {
            display: inline-flex;
            align-items: center;
            background: #f0fdf4;
            color: #166534;
            padding: 6px 12px;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.95rem;
            margin-bottom: 20px;
        }

        /* Action Forms & Links */
        .bid-form {
            background: var(--light);
            padding: 20px;
            border-radius: 12px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            border: 1px solid var(--border);
        }

        .bid-form input {
            flex: 1;
            min-width: 150px;
            padding: 10px 15px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 0.9rem;
        }

        .bid-form input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        }

        .btn-apply {
            background-color: var(--primary);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
        }

        .btn-apply:hover {
            background-color: var(--primary-hover);
        }

        .view-bids-link {
            display: inline-block;
            text-decoration: none;
            background-color: var(--white);
            color: var(--primary);
            border: 2px solid var(--primary);
            padding: 8px 18px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.2s;
        }

        .view-bids-link:hover {
            background-color: var(--primary);
            color: var(--white);
        }

        /* Empty State */
        .no-jobs {
            text-align: center;
            padding: 80px 20px;
            background: var(--white);
            border-radius: 16px;
            border: 2px dashed var(--border);
            color: var(--text-muted);
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <h2>FreelanceHub</h2>
        <div class="nav-links">
            <a href="dashboard.jsp">Dashboard</a>
            <a href="login.jsp">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="header-area">
            <h2>Available Jobs</h2>
            <p style="color: var(--text-muted);">Browse through active opportunities and submit your proposals.</p>
        </div>

        <% if (jobs != null && !jobs.isEmpty()) {
            for (Job job : jobs) {
        %>

        <div class="job-card">
            <h3><%= job.getTitle() %></h3>
            <div class="job-description">
                <%= job.getDescription() %>
            </div>
            
            <div class="budget-tag">
                Budget: ₹<%= job.getBudget() %>
            </div>

            <% if ("freelancer".equals(user.getRole())) { %>
            <form action="./applyBid" method="post" class="bid-form">
                <input type="hidden" name="jobId" value="<%= job.getId() %>">

                <input type="number" name="amount" placeholder="Your Bid (₹)" required>
                <input type="text" name="message" placeholder="Include a brief proposal message..." required>

                <button type="submit" class="btn-apply">Submit Application</button>
            </form>
            <% } %>

            <% if ("client".equals(user.getRole())) { %>
                <div style="border-top: 1px solid var(--border); padding-top: 15px; margin-top: 5px;">
                    <a href="./viewBids?jobId=<%= job.getId() %>" class="view-bids-link">View Received Bids</a>
                </div>
            <% } %>
        </div>

        <%  }
           } else { %>
            <div class="no-jobs">
                <p>No jobs are available at this moment. Please check back later.</p>
            </div>
        <% } %>

    </div>

</body>
</html>