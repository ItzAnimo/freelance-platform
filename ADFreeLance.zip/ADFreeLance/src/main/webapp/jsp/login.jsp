<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - FreelanceHub</title>
    <style>
        /* Modern Reset & Variables (Synced with Index) */
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --dark: #1e293b;
            --light: #f8fafc;
            --text-main: #334155;
            --text-muted: #64748b;
            --white: #ffffff;
            --error-bg: #fee2e2;
            --error-text: #b91c1c;
            --shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        }

        body {
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background-color: var(--light);
            color: var(--text-main);
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Navbar */
        .navbar {
            background-color: var(--white);
            padding: 1rem 10%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow);
        }

        .navbar h2 {
            margin: 0;
            color: var(--primary);
            font-size: 1.5rem;
            font-weight: 800;
        }

        .nav-links a {
            color: var(--dark);
            text-decoration: none;
            margin-left: 25px;
            font-size: 0.95rem;
            font-weight: 500;
        }

        /* Login Container */
        .main-content {
            flex-grow: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-card {
            background: var(--white);
            width: 100%;
            max-width: 400px;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
        }

        .login-card h2 {
            text-align: center;
            margin-top: 0;
            margin-bottom: 1.5rem;
            color: var(--dark);
            font-size: 1.75rem;
            letter-spacing: -0.5px;
        }

        /* Form Styling */
        .form-group {
            margin-bottom: 1.25rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text-main);
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.2s;
            box-sizing: border-box; /* Crucial for padding */
        }

        input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        }

        .btn {
            width: 100%;
            padding: 12px;
            background-color: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s, transform 0.1s;
            margin-top: 1rem;
        }

        .btn:hover {
            background-color: var(--primary-hover);
        }

        .btn:active {
            transform: scale(0.98);
        }

        /* Error Message */
        .error {
            background-color: var(--error-bg);
            color: var(--error-text);
            padding: 10px;
            border-radius: 6px;
            text-align: center;
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
            border: 1px solid rgba(185, 28, 28, 0.2);
        }

        .footer-text {
            text-align: center;
            margin-top: 1.5rem;
            font-size: 0.95rem;
            color: var(--text-muted);
        }

        .footer-text a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
        }

        .footer-text a:hover {
            text-decoration: underline;
        }

        /* Debug/Age Styling */
        .debug-info {
            text-align: center;
            padding: 1rem;
            font-size: 0.8rem;
            color: var(--text-muted);
            opacity: 0.6;
        }
    </style>
</head>

<body>

    <nav class="navbar">
        <h2>FreelanceHub</h2>
        <div class="nav-links">
            <a href="index.jsp">Home</a>
            <a href="register.jsp">Register</a>
        </div>
    </nav>

    <div class="main-content">
        <div class="login-card">
            <h2>Welcome Back</h2>

            <% 
                String error = request.getParameter("error");
                if ("1".equals(error)) {
            %>
                <div class="error">Invalid email or password</div>
            <% } %>

            <form action="${pageContext.request.contextPath}/login" method="post">
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="text" name="email" placeholder="name@company.com" required>
                </div>
                
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="••••••••" required>
                </div>

                <button type="submit" class="btn">Sign In</button>
            </form>

            <div class="footer-text">
                <p>Don't have an account? <a href="register.jsp">Create one</a></p>
            </div>
        </div>
    </div>

    <div class="debug-info">
        <% int age = 23; %>
        System Context Age: <%=age%>
    </div>

</body>
</html>