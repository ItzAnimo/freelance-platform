<%@ page import="model.User" %>
<%
    // Prevent browser from caching protected pages
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    response.setHeader("Pragma", "no-cache");
    response.setDateHeader("Expires", 0);

    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | FreelanceHub</title>
    <style>
        /* Modern Reset & Variables (Synced with Platform Theme) */
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --dark: #1e293b;
            --light: #f8fafc;
            --text-main: #334155;
            --text-muted: #64748b;
            --white: #ffffff;
            --shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        }

        body {
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            background-color: var(--light);
            color: var(--text-main);
        }

        /* Navbar Enhancement */
        .navbar {
            background-color: var(--dark);
            color: var(--white);
            padding: 1rem 10%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow);
        }

        .navbar .brand {
            font-weight: 800;
            font-size: 1.2rem;
            letter-spacing: -0.5px;
        }

        .navbar .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .navbar a {
            color: #cbd5e1;
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.2s;
        }

        .navbar a:hover {
            color: var(--white);
        }

        .logout-btn {
            background: rgba(255, 255, 255, 0.1);
            padding: 6px 15px;
            border-radius: 6px;
        }

        /* Dashboard Layout */
        .container {
            max-width: 1000px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .welcome-header {
            margin-bottom: 30px;
        }

        .welcome-header h1 {
            font-size: 1.8rem;
            color: var(--dark);
            margin-bottom: 5px;
        }

        .role-badge {
            display: inline-block;
            background: #e0e7ff;
            color: var(--primary);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        /* Action Grid */
        .action-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .action-card {
            background: var(--white);
            padding: 25px;
            border-radius: 12px;
            box-shadow: var(--shadow);
            text-decoration: none;
            color: inherit;
            transition: transform 0.2s, box-shadow 0.2s;
            display: flex;
            flex-direction: column;
            border: 1px solid #e2e8f0;
        }

        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            border-color: var(--primary);
        }

        .action-card h3 {
            margin: 0 0 10px 0;
            color: var(--primary);
        }

        .action-card p {
            margin: 0;
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        /* Footer */
        .footer {
            text-align: center;
            margin-top: 60px;
            padding: 20px;
            color: var(--text-muted);
            font-size: 0.85rem;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <div class="brand">FreelanceHub</div>
        <div class="user-info">
            <span>Welcome, <strong><%= user.getName() %></strong></span>
            <a href="${pageContext.request.contextPath}/logout" class="logout-btn">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="welcome-header">
            <h1>User Dashboard</h1>
            <span class="role-badge"><%= user.getRole() %></span>
        </div>

        <div class="action-grid">
            
            <%-- Role-Based View Logic --%>
            <% if ("client".equals(user.getRole())) { %>
                
                <a href="postjob.jsp" class="action-card">
                    <h3>Post a Job</h3>
                    <p>Describe your project and find the perfect talent for your needs.</p>
                </a>

                <a href="../viewJobs" class="action-card">
                    <h3>Manage Jobs</h3>
                    <p>View your active postings and review applications from freelancers.</p>
                </a>

                <a href="../viewFreelancers" class="action-card">
                    <h3>Hire Developer</h3>
                    <p>Browse through our directory of skilled developers and creative talent.</p>
                </a>

            <% } else { %>

                <a href="../viewJobs" class="action-card">
                    <h3>Browse Jobs</h3>
                    <p>Find new opportunities that match your skill set and interests.</p>
                </a>

                <a href="profile.jsp" class="action-card">
                    <h3>Create Profile</h3>
                    <p>Set up your professional portfolio to stand out to potential clients.</p>
                </a>

                <a href="../viewJobs" class="action-card">
                    <h3>Get Project</h3>
                    <p>View recommended projects and start sending your proposals.</p>
                </a>

            <% } %>

        </div>
    </div>

    <div class="footer">
        &copy; 2026 FreelanceHub Dashboard
    </div>

</body>
</html>