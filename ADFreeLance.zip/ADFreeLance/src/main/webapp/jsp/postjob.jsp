<%@ page import="model.User" %>
<%
    User user = (User) session.getAttribute("user");
    if (user == null || !"client".equals(user.getRole())) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post a New Job | FreelanceHub</title>
    <style>
        /* Modern Reset & Variables */
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --dark: #1e293b;
            --light: #f8fafc;
            --text-main: #334155;
            --text-muted: #64748b;
            --white: #ffffff;
            --border: #e2e8f0;
            --shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        body {
            font-family: 'Segoe UI', Roboto, sans-serif;
            background-color: var(--light);
            color: var(--text-main);
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Navbar Style (Simplified for consistency) */
        .header {
            background-color: var(--white);
            padding: 1rem 10%;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header a {
            text-decoration: none;
            color: var(--primary);
            font-weight: 600;
            font-size: 0.9rem;
        }

        /* Container & Card */
        .main-content {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }

        .form-card {
            background: var(--white);
            width: 100%;
            max-width: 500px;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: var(--shadow);
        }

        .form-card h2 {
            margin-top: 0;
            margin-bottom: 0.5rem;
            color: var(--dark);
            font-size: 1.75rem;
            letter-spacing: -0.5px;
        }

        .form-card p {
            color: var(--text-muted);
            margin-bottom: 2rem;
            font-size: 0.95rem;
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--dark);
            text-transform: uppercase;
            letter-spacing: 0.025em;
        }

        input[type="text"],
        input[type="number"],
        textarea {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 1rem;
            font-family: inherit;
            color: var(--text-main);
            box-sizing: border-box;
            transition: all 0.2s ease;
        }

        textarea {
            min-height: 120px;
            resize: vertical;
        }

        input:focus, textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
        }

        .btn {
            background-color: var(--primary);
            color: white;
            padding: 14px;
            border: none;
            border-radius: 8px;
            width: 100%;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(79, 70, 229, 0.2);
        }

        .btn:hover {
            background-color: var(--primary-hover);
            transform: translateY(-1px);
            box-shadow: 0 6px 12px rgba(79, 70, 229, 0.3);
        }

        .btn:active {
            transform: translateY(0);
        }

        /* Footer Decoration */
        .cancel-link {
            display: block;
            text-align: center;
            margin-top: 1.5rem;
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.9rem;
        }

        .cancel-link:hover {
            color: var(--primary);
        }
    </style>
</head>
<body>

    <header class="header">
        <div style="font-weight: 800; color: var(--dark);">FreelanceHub</div>
        <a href="dashboard.jsp">← Back to Dashboard</a>
    </header>

    <div class="main-content">
        <div class="form-card">
            <h2>Post a Job</h2>
            <p>Ready to find your next great hire? Fill out the details below.</p>

            <form action="../postJob" method="post">
                <div class="form-group">
                    <label for="title">Project Title</label>
                    <input type="text" id="title" name="title" placeholder="e.g. Build a React Dashboard" required>
                </div>

                <div class="form-group">
                    <label for="description">Job Description</label>
                    <textarea id="description" name="description" placeholder="Describe the scope of work, requirements, and timeline..." required></textarea>
                </div>

                <div class="form-group">
                    <label for="budget">Project Budget ($)</label>
                    <input type="number" id="budget" name="budget" placeholder="500" min="1" required>
                </div>

                <button type="submit" class="btn">Publish Job Posting</button>
            </form>

            <a href="dashboard.jsp" class="cancel-link">Cancel and return</a>
        </div>
    </div>

</body>
</html>