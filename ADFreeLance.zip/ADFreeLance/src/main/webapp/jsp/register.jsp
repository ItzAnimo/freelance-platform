<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join FreelanceHub | Create Account</title>
    <style>
        /* Modern Variables (Consistent with the rest of the site) */
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --dark: #1e293b;
            --light: #f8fafc;
            --text-main: #334155;
            --text-muted: #64748b;
            --white: #ffffff;
            --border: #e2e8f0;
            --error-bg: #fee2e2;
            --error-text: #b91c1c;
            --shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        body {
            font-family: 'Segoe UI', Roboto, sans-serif;
            background-color: var(--light);
            color: var(--text-main);
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Navbar Enhancement */
        .navbar {
            background-color: var(--white);
            padding: 1rem 10%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);
        }

        .navbar h2 {
            margin: 0;
            color: var(--primary);
            font-size: 1.4rem;
            font-weight: 800;
            letter-spacing: -0.5px;
        }

        .nav-links a {
            color: var(--dark);
            text-decoration: none;
            margin-left: 20px;
            font-size: 0.9rem;
            font-weight: 500;
        }

        /* Register Container */
        .main-content {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
        }

        .register-card {
            background: var(--white);
            width: 100%;
            max-width: 420px;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: var(--shadow);
        }

        .register-card h2 {
            text-align: center;
            margin-top: 0;
            margin-bottom: 0.5rem;
            color: var(--dark);
            font-size: 1.75rem;
        }

        .register-card p {
            text-align: center;
            color: var(--text-muted);
            margin-bottom: 2rem;
            font-size: 0.95rem;
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 1.25rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--text-main);
        }

        input, select {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 1rem;
            font-family: inherit;
            box-sizing: border-box;
            transition: all 0.2s;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
        }

        .btn {
            width: 100%;
            padding: 14px;
            background-color: var(--primary);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            margin-top: 1rem;
        }

        .btn:hover {
            background-color: var(--primary-hover);
            transform: translateY(-1px);
        }

        /* Feedback Styles */
        .error {
            background-color: var(--error-bg);
            color: var(--error-text);
            padding: 12px;
            border-radius: 8px;
            text-align: center;
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
            border: 1px solid rgba(185, 28, 28, 0.1);
        }

        .footer-text {
            text-align: center;
            margin-top: 1.5rem;
            font-size: 0.95rem;
            color: var(--text-muted);
        }

        .footer-text a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
        }

        .footer-text a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <nav class="navbar">
        <h2>FreelanceHub</h2>
        <div class="nav-links">
            <a href="../index.jsp">Home</a>
            <a href="login.jsp">Login</a>
        </div>
    </nav>

    <main class="main-content">
        <div class="register-card">
            <h2>Create Account</h2>
            <p>Join thousands of freelancers and clients today.</p>

            <% 
                String error = request.getParameter("error");
                if ("1".equals(error)) {
            %>
                <div class="error">Registration failed. Please try again.</div>
            <% } %>

            <form action="../register" method="post">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="name" placeholder="John Doe" required>
                </div>

                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" placeholder="john@example.com" required>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="••••••••" required>
                </div>

                <div class="form-group">
                    <label>I am a...</label>
                    <select name="role" required>
                        <option value="">Select Role</option>
                        <option value="client">Client (Hiring Talent)</option>
                        <option value="freelancer">Freelancer (Finding Work)</option>
                    </select>
                </div>

                <button type="submit" class="btn">Create My Account</button>
            </form>

            <div class="footer-text">
                <p>Already have an account? <a href="login.jsp">Log in here</a></p>
            </div>
        </div>
    </main>

</body>
</html>