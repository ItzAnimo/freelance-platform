<%@ page import="model.User" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    response.setHeader("Pragma", "no-cache");
    response.setDateHeader("Expires", 0);

    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile | FreelanceHub</title>
    <style>
        /* Modern Variables (Synced with FreelanceHub Theme) */
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --dark: #1e293b;
            --light: #f8fafc;
            --text-main: #334155;
            --text-muted: #64748b;
            --white: #ffffff;
            --border: #e2e8f0;
            --shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        }

        body {
            font-family: 'Segoe UI', Roboto, sans-serif;
            background-color: var(--light);
            color: var(--text-main);
            margin: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Navbar Style */
        .navbar {
            background-color: var(--white);
            padding: 1rem 10%;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar .brand {
            font-weight: 800;
            color: var(--primary);
            font-size: 1.2rem;
            text-decoration: none;
        }

        /* Profile Card */
        .main-content {
            flex: 1;
            display: flex;
            align-items: flex-start;
            justify-content: center;
            padding: 50px 20px;
        }

        .profile-card {
            background: var(--white);
            width: 100%;
            max-width: 600px;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: var(--shadow);
        }

        .profile-card h2 {
            margin: 0 0 0.5rem 0;
            color: var(--dark);
            font-size: 1.75rem;
        }

        .profile-card p {
            color: var(--text-muted);
            margin-bottom: 2rem;
            font-size: 0.95rem;
        }

        /* Form Layout */
        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--dark);
            text-transform: uppercase;
            letter-spacing: 0.025em;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 1rem;
            font-family: inherit;
            color: var(--text-main);
            box-sizing: border-box;
            transition: all 0.2s;
        }

        textarea {
            min-height: 100px;
            resize: vertical;
        }

        input:focus, textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
        }

        /* Custom Checkbox Styling */
        .checkbox-group {
            display: flex;
            align-items: center;
            background: var(--light);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 2rem;
            cursor: pointer;
        }

        .checkbox-group input {
            width: 18px;
            height: 18px;
            margin-right: 12px;
            cursor: pointer;
            accent-color: var(--primary);
        }

        .checkbox-text {
            font-weight: 500;
            font-size: 0.95rem;
            color: var(--dark);
        }

        /* Button Styling */
        .btn-save {
            background-color: var(--primary);
            color: white;
            padding: 14px 28px;
            border: none;
            border-radius: 8px;
            width: 100%;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-save:hover {
            background-color: var(--primary-hover);
            transform: translateY(-1px);
        }

        .btn-save:active {
            transform: translateY(0);
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <a href="dashboard.jsp" class="brand">FreelanceHub</a>
        <a href="dashboard.jsp" style="text-decoration: none; color: var(--text-muted); font-size: 0.9rem;">Back to Dashboard</a>
    </nav>

    <div class="main-content">
        <div class="profile-card">
            <h2>Professional Profile</h2>
            <p>Update your details so clients and collaborators can find you.</p>

            <form action="../updateProfile" method="post">
                <div class="form-group">
                    <label for="contact">Contact Number</label>
                    <input type="text" id="contact" name="contact" placeholder="+1 (555) 000-0000" required>
                </div>

                <div class="form-group">
                    <label for="education">Education</label>
                    <textarea id="education" name="education" placeholder="E.g. B.S. in Computer Science, University of Technology"></textarea>
                </div>

                <div class="form-group">
                    <label for="skills">Skills & Expertise</label>
                    <textarea id="skills" name="skills" placeholder="E.g. Java, Spring Boot, React, UI Design..."></textarea>
                </div>

                <label class="checkbox-group">
                    <input type="checkbox" name="available">
                    <span class="checkbox-text">I am currently available for new projects</span>
                </label>

                <button type="submit" class="btn-save">Save Profile Changes</button>
            </form>
        </div>
    </div>

</body>
</html>