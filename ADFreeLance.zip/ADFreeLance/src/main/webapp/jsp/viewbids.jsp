<%@ page import="java.util.*, model.Bid, model.User" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>

<%
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    response.setHeader("Pragma", "no-cache");
    response.setDateHeader("Expires", 0);

    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
        return;
    }

    List<Bid> bids = (List<Bid>) request.getAttribute("bids");
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Bids | FreelanceHub</title>
    <style>
        /* Modern Variables (Synced with Platform Theme) */
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --dark: #1e293b;
            --light: #f8fafc;
            --text-main: #334155;
            --text-muted: #64748b;
            --white: #ffffff;
            --border: #e2e8f0;
            --shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
        }

        body {
            font-family: 'Segoe UI', Roboto, sans-serif;
            background-color: var(--light);
            color: var(--text-main);
            margin: 0;
            padding-bottom: 50px;
        }

        /* Navbar */
        .navbar {
            background-color: var(--white);
            padding: 1rem 10%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow);
            border-bottom: 1px solid var(--border);
        }

        .navbar h2 {
            margin: 0;
            color: var(--primary);
            font-size: 1.4rem;
            font-weight: 800;
        }

        .nav-links a {
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
        }

        /* Container */
        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .header-section {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-section h2 {
            color: var(--dark);
            font-size: 1.75rem;
            margin: 0;
        }

        .bid-count {
            background: var(--primary);
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        /* Bid Card Styling */
        .bid-card {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
            transition: transform 0.2s;
        }

        .bid-card:hover {
            transform: translateY(-2px);
            border-color: var(--primary);
        }

        .bid-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            border-bottom: 1px solid var(--light);
            padding-bottom: 15px;
        }

        .freelancer-info h4 {
            margin: 0;
            color: var(--dark);
            font-size: 1.1rem;
        }

        .freelancer-id {
            font-size: 0.85rem;
            color: var(--text-muted);
        }

        .bid-amount {
            font-size: 1.25rem;
            font-weight: 800;
            color: var(--primary);
        }

        .bid-message {
            background-color: var(--light);
            padding: 15px;
            border-radius: 8px;
            font-size: 0.95rem;
            line-height: 1.5;
            color: var(--text-main);
            border-left: 4px solid var(--border);
        }

        /* Empty State */
        .no-bids {
            text-align: center;
            padding: 60px 20px;
            background: var(--white);
            border-radius: 12px;
            border: 2px dashed var(--border);
        }

        .no-bids p {
            color: var(--text-muted);
            font-size: 1.1rem;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <h2>FreelanceHub</h2>
        <div class="nav-links">
            <a href="dashboard.jsp">← Back to Dashboard</a>
        </div>
    </nav>

    <div class="container">
        <div class="header-section">
            <h2>Bids for this Job</h2>
            <% if (bids != null) { %>
                <span class="bid-count"><%= bids.size() %> Total</span>
            <% } %>
        </div>

        <% 
            if (bids != null && !bids.isEmpty()) {
                for (Bid bid : bids) {
        %>

        <div class="bid-card">
            <div class="bid-header">
                <div class="freelancer-info">
                    <div class="freelancer-id">Freelancer Account</div>
                    <h4>ID: <%= bid.getFreelancerId() %></h4>
                </div>
                <div class="bid-amount">
                    ₹<%= bid.getAmount() %>
                </div>
            </div>
            
            <div class="bid-message">
                <strong>Proposal Message:</strong><br>
                <%= bid.getMessage() %>
            </div>
        </div>

        <%  
                }
            } else { 
        %>
            <div class="no-bids">
                <p>No bids have been submitted for this job yet.</p>
            </div>
        <% } %>

    </div>

</body>
</html>