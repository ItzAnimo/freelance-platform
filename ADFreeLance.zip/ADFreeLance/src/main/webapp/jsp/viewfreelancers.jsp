<%@ page import="java.util.*, model.User" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" %>

<%
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    response.setHeader("Pragma", "no-cache");
    response.setDateHeader("Expires", 0);

    User user = (User) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
        return;
    }

    List<User> list = (List<User>) request.getAttribute("freelancers");
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hire Developers | FreelanceHub</title>
    <style>
        /* Modern Variables */
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --dark: #1e293b;
            --light: #f8fafc;
            --text-main: #334155;
            --text-muted: #64748b;
            --white: #ffffff;
            --border: #e2e8f0;
            --shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
        }

        body {
            font-family: 'Segoe UI', Roboto, sans-serif;
            background-color: var(--light);
            color: var(--text-main);
            margin: 0;
            padding-bottom: 50px;
        }

        /* Navbar */
        .navbar {
            background-color: var(--white);
            padding: 1rem 10%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: var(--shadow);
            border-bottom: 1px solid var(--border);
        }

        .navbar h2 {
            margin: 0;
            color: var(--primary);
            font-size: 1.4rem;
            font-weight: 800;
        }

        .nav-links a {
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
        }

        /* Header Area */
        .container {
            max-width: 1100px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .header-section {
            margin-bottom: 30px;
            border-bottom: 2px solid var(--border);
            padding-bottom: 15px;
        }

        .header-section h2 {
            color: var(--dark);
            font-size: 1.8rem;
            margin: 0;
        }

        /* Responsive Talent Grid */
        .talent-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 25px;
        }

        /* Profile Card Styling */
        .profile-card {
            background: var(--white);
            border-radius: 12px;
            padding: 25px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
        }

        .profile-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            border-color: var(--primary);
        }

        .card-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .avatar-circle {
            width: 50px;
            height: 50px;
            background: #e0e7ff;
            color: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 1.2rem;
            margin-right: 15px;
        }

        .name-info h3 {
            margin: 0;
            font-size: 1.1rem;
            color: var(--dark);
        }

        .name-info .contact-text {
            font-size: 0.85rem;
            color: var(--text-muted);
        }

        /* Info Sections */
        .info-label {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            color: var(--text-muted);
            margin-bottom: 4px;
            letter-spacing: 0.025em;
        }

        .info-value {
            font-size: 0.95rem;
            margin-bottom: 15px;
            color: var(--text-main);
        }

        /* Skill Pills */
        .skills-container {
            margin-top: auto;
            padding-top: 15px;
            border-top: 1px solid var(--light);
        }

        .skills-list {
            font-size: 0.9rem;
            line-height: 1.4;
            color: var(--primary);
            font-weight: 500;
        }

        /* Empty State */
        .no-data {
            text-align: center;
            grid-column: 1 / -1;
            padding: 50px;
            background: var(--white);
            border-radius: 12px;
            border: 2px dashed var(--border);
            color: var(--text-muted);
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <h2>FreelanceHub</h2>
        <div class="nav-links">
            <a href="dashboard.jsp">← Back to Dashboard</a>
        </div>
    </nav>

    <div class="container">
        <div class="header-section">
            <h2>Hire Professional Developers</h2>
        </div>

        <div class="talent-grid">
            <% 
                if (list != null && !list.isEmpty()) {
                    for (User u : list) { 
            %>
                <div class="profile-card">
                    <div class="card-header">
                        <div class="avatar-circle">
                            <%= u.getName().substring(0, 1).toUpperCase() %>
                        </div>
                        <div class="name-info">
                            <h3><%= u.getName() %></h3>
                            <div class="contact-text">Contact: <%= u.getContact() %></div>
                        </div>
                    </div>

                    <div class="info-label">Education</div>
                    <div class="info-value"><%= (u.getEducation() != null && !u.getEducation().isEmpty()) ? u.getEducation() : "Not specified" %></div>

                    <div class="skills-container">
                        <div class="info-label">Skills & Expertise</div>
                        <div class="skills-list">
                            <%= u.getSkills() %>
                        </div>
                    </div>
                </div>
            <% 
                    } 
                } else { 
            %>
                <div class="no-data">
                    <p>No freelancers are available at the moment. Please check back later.</p>
                </div>
            <% } %>
        </div>
    </div>

</body>
</html>