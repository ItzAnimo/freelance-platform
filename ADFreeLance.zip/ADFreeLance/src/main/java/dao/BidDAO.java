package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


import model.Bid;
import util.DBConnection;

public class BidDAO {

    // Add Bid
    public boolean addBid(Bid bid) {
        boolean status = false;

        try {
            Connection con = DBConnection.getConnection();
            String query = "INSERT INTO bids(job_id, freelancer_id, amount, message) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, bid.getJobId());
            ps.setInt(2, bid.getFreelancerId());
            ps.setDouble(3, bid.getAmount());
            ps.setString(4, bid.getMessage());

            int rows = ps.executeUpdate();
            if (rows > 0) status = true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }
    public List<Bid> getBidsByJobId(int jobId) {
        List<Bid> list = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();
            String query = "SELECT * FROM bids WHERE job_id=?";
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, jobId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Bid bid = new Bid();
                bid.setId(rs.getInt("id"));
                bid.setJobId(rs.getInt("job_id"));
                bid.setFreelancerId(rs.getInt("freelancer_id"));
                bid.setAmount(rs.getDouble("amount"));
                bid.setMessage(rs.getString("message"));

                list.add(bid);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}