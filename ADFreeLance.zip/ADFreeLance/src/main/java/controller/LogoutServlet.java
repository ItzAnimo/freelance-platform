package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        // Invalidate the session to clear all user data
        HttpSession session = req.getSession(false);
        if (session != null) {
            session.invalidate();
        }

        // Prevent browser from caching the page after logout
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        res.setHeader("Pragma", "no-cache");
        res.setDateHeader("Expires", 0);

        // Redirect to login page
        res.sendRedirect(req.getContextPath() + "/jsp/login.jsp");
    }
}
