package controller;
import java.io.IOException;

import dao.UserDAO;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.User;

@WebServlet("/updateProfile")
public class UpdateProfileServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");

        String contact = req.getParameter("contact");
        String education = req.getParameter("education");
        String skills = req.getParameter("skills");
        boolean available = req.getParameter("available") != null;

        UserDAO dao = new UserDAO();
        dao.updateProfile(user.getId(), contact, education, skills, available);

        res.sendRedirect("jsp/dashboard.jsp");
    }
}