package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.util.List;

import dao.JobDAO;
import model.Job;

@WebServlet("/viewJobs")
public class ViewJobsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        // Check session - redirect to login if not logged in
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            res.sendRedirect(req.getContextPath() + "/jsp/login.jsp");
            return;
        }

        try {
            JobDAO dao = new JobDAO();
            List<Job> jobs = dao.getAllJobs();

            req.setAttribute("jobs", jobs);

            RequestDispatcher rd = req.getRequestDispatcher("jsp/viewjobs.jsp");
            rd.forward(req, res);

        } catch (Exception e) {
            e.printStackTrace();
            res.sendRedirect(req.getContextPath() + "/jsp/dashboard.jsp");
        }
    }
}
