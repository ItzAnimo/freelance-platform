package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.util.List;

import dao.BidDAO;
import model.Bid;

@WebServlet("/viewBids")
public class ViewBidsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        // Check session
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            res.sendRedirect(req.getContextPath() + "/jsp/login.jsp");
            return;
        }

        int jobId = Integer.parseInt(req.getParameter("jobId"));

        BidDAO dao = new BidDAO();
        List<Bid> bids = dao.getBidsByJobId(jobId);

        req.setAttribute("bids", bids);
        RequestDispatcher rd = req.getRequestDispatcher("jsp/viewbids.jsp");
        rd.forward(req, res);
    }
}
